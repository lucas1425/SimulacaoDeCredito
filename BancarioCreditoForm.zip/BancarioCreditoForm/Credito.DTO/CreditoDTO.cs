﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credito.DTO
{
    public class CreditoDTO
    {
        public int numParcela { get; set; }
        public string vlrParcela { get; set; }
        public string vlrParcelaExp { get; set; }
        public string vlrParcelaLin { get; set; }
        public string vlrJurosExp { get; set; }
        public string vlrJurosLin { get; set; }
    }
}
