﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Credito.BLL;
using Credito.DTO;

namespace BoncarioCreditoForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void limpar()
        {
            textBoxTaxaDeJuros.Text = "";
            textBoxQtdeDeParcelas.Text = "";
            textBoxValorDoEmprestimo.Text = "";
        }
        private void btnSimular_Click(object sender, EventArgs e)
        {
            try
            {
                var varTxJuros = textBoxTaxaDeJuros.Text.Replace('.', ',');
                var varQtdeParcelas = textBoxQtdeDeParcelas.Text.Replace('.', ',');
                var varVlrEmprestimo = textBoxValorDoEmprestimo.Text.Replace('.', ',');
                double txJuros = Convert.ToDouble(varTxJuros);
                int qtdeParcelas = Convert.ToInt32(varQtdeParcelas);
                double vlrEmprestimo = Convert.ToDouble(varVlrEmprestimo);
                carregaGrid(txJuros, qtdeParcelas, vlrEmprestimo);
            }
            catch (Exception )
            {
                if (textBoxTaxaDeJuros.Text.Equals("")|| textBoxQtdeDeParcelas.Text.Equals("") || textBoxValorDoEmprestimo.Text.Equals(""))
                {
                    MessageBox.Show("Todos os campos devem ser preenchidos!","Aviso");
                }
                else
                {
                    MessageBox.Show("Digite apenas valores numéricos!", "Aviso");
                    limpar();
                }                
            }
        }

        private void carregaGrid(double txJuros, int qtdeParcelas, double vlrEmprestimo)
        {
            try
            {
                IList<CreditoDTO> listParcelas = new List<CreditoDTO>();
                listParcelas = new CreditoBLL().mostraParcelas(qtdeParcelas, txJuros, vlrEmprestimo);
                /*Preencher dados no DataGridView*/
                dataGridView1.DataSource = listParcelas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
