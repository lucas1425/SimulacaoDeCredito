﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credito.DTO;

namespace Credito.DAL
{
    public class CreditoDAL
    {
        public static class Constants
        {
            public const int periodoParcela = 30;
        }


        public double ValorParcela(double vlrEmprestimo, int qtdeParcela)
        {
            double valorParcela;
            valorParcela = vlrEmprestimo / qtdeParcela;
            return valorParcela;
        }

        public double JurosLinear(double vlrEmprestimo, int qtdeParcela, double txJuros, int qtdeDiasDesdeInicio)
        {
            try
            {
                double valorJuros;
                valorJuros = (ValorParcela(vlrEmprestimo, qtdeParcela) * txJuros * qtdeDiasDesdeInicio) / (100 * Constants.periodoParcela);
                return Math.Round(valorJuros,2);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public double JurosExponencial(double vlrEmprestimo, int qtdeParcela, double txJuros, int qtdeDiasDesdeInicio)
        {
            try
            {
                double x = (1+(txJuros/100));
                double y = qtdeDiasDesdeInicio / Constants.periodoParcela;
                double pot = Math.Pow(x, y);
                double valorJuros;
                double valorParcela = ValorParcela(vlrEmprestimo, qtdeParcela);
                valorJuros = valorParcela * (pot-1);
                
                return Math.Round(valorJuros, 2);
            }
            catch ( Exception ex)
            {
                throw ex;
            }
        }

        public IList<CreditoDTO> MostraParcelas(int parcelas, double txJuros, double vlrEmprestimo)
        {
            
            try
            {
                
                int i = 0;
                IList<CreditoDTO> listParcela = new List<CreditoDTO>();

                while (i < parcelas)
                {
                    CreditoDTO parcela = new CreditoDTO();
                    i++;
                    int periodo = i * Constants.periodoParcela;
                    double valorLin,valorExp;
                    valorLin = JurosLinear(vlrEmprestimo, parcelas, txJuros, periodo) + ValorParcela(vlrEmprestimo, parcelas);
                    valorExp = JurosExponencial(vlrEmprestimo, parcelas, txJuros, periodo) + ValorParcela(vlrEmprestimo, parcelas);


                    parcela.numParcela = i;
                    parcela.vlrParcela = Convert.ToString(ValorParcela(vlrEmprestimo, parcelas).ToString("N2"));
                    parcela.vlrJurosLin = Convert.ToString(JurosLinear( vlrEmprestimo,  parcelas,  txJuros, periodo).ToString("N2"));
                    parcela.vlrJurosExp = Convert.ToString(JurosExponencial(vlrEmprestimo, parcelas, txJuros, periodo).ToString("N2"));
                    parcela.vlrParcelaLin = Convert.ToString(valorLin.ToString("N2"));
                    parcela.vlrParcelaExp = Convert.ToString(valorExp.ToString("N2"));
                    listParcela.Add(parcela);
                }
                return listParcela;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
    }

}
