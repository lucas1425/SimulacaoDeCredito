﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Credito.DAL;
using Credito.DTO;


namespace Credito.BLL
{
    public class CreditoBLL
    {
        public double jurosLinear(double vlrEmprestimo, int qtdeParcela, double txJuros, int qtdeDiasDesdeInicio)
        {

            try
            {
                return new CreditoDAL().JurosLinear(vlrEmprestimo, qtdeParcela, txJuros, qtdeDiasDesdeInicio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public double jurosExponencial(double vlrEmprestimo, int qtdeParcela, double txJuros, int qtdeDiasDesdeInicio)
        {

            try
            {
                return new CreditoDAL().JurosExponencial(vlrEmprestimo, qtdeParcela, txJuros, qtdeDiasDesdeInicio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public IList<CreditoDTO> mostraParcelas(int parcelas, double txJuros, double vlrEmprestimo)
        {
            try
            {
                return new CreditoDAL().MostraParcelas(parcelas, txJuros, vlrEmprestimo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        }
}
