﻿
namespace BoncarioCreditoForm
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxValorDoEmprestimo = new System.Windows.Forms.TextBox();
            this.textBoxQtdeDeParcelas = new System.Windows.Forms.TextBox();
            this.textBoxTaxaDeJuros = new System.Windows.Forms.TextBox();
            this.labelValorDoEmprestimo = new System.Windows.Forms.Label();
            this.labelQtdeDeParcela = new System.Windows.Forms.Label();
            this.labelTaxaJuros = new System.Windows.Forms.Label();
            this.btnSimular = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.creditoDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.numParcela = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vlrParcela = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vlrJurosLin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vlrparcelaLin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vlrJurosExp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vlrParcelaExp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.creditoDTOBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxValorDoEmprestimo
            // 
            this.textBoxValorDoEmprestimo.Location = new System.Drawing.Point(15, 55);
            this.textBoxValorDoEmprestimo.Name = "textBoxValorDoEmprestimo";
            this.textBoxValorDoEmprestimo.Size = new System.Drawing.Size(100, 20);
            this.textBoxValorDoEmprestimo.TabIndex = 1;
            // 
            // textBoxQtdeDeParcelas
            // 
            this.textBoxQtdeDeParcelas.Location = new System.Drawing.Point(15, 107);
            this.textBoxQtdeDeParcelas.Name = "textBoxQtdeDeParcelas";
            this.textBoxQtdeDeParcelas.Size = new System.Drawing.Size(100, 20);
            this.textBoxQtdeDeParcelas.TabIndex = 2;
            // 
            // textBoxTaxaDeJuros
            // 
            this.textBoxTaxaDeJuros.Location = new System.Drawing.Point(15, 155);
            this.textBoxTaxaDeJuros.Name = "textBoxTaxaDeJuros";
            this.textBoxTaxaDeJuros.Size = new System.Drawing.Size(100, 20);
            this.textBoxTaxaDeJuros.TabIndex = 3;
            // 
            // labelValorDoEmprestimo
            // 
            this.labelValorDoEmprestimo.AutoSize = true;
            this.labelValorDoEmprestimo.Location = new System.Drawing.Point(12, 39);
            this.labelValorDoEmprestimo.Name = "labelValorDoEmprestimo";
            this.labelValorDoEmprestimo.Size = new System.Drawing.Size(105, 13);
            this.labelValorDoEmprestimo.TabIndex = 5;
            this.labelValorDoEmprestimo.Text = "Valor do emprestimo:";
            // 
            // labelQtdeDeParcela
            // 
            this.labelQtdeDeParcela.AutoSize = true;
            this.labelQtdeDeParcela.Location = new System.Drawing.Point(12, 91);
            this.labelQtdeDeParcela.Name = "labelQtdeDeParcela";
            this.labelQtdeDeParcela.Size = new System.Drawing.Size(123, 13);
            this.labelQtdeDeParcela.TabIndex = 6;
            this.labelQtdeDeParcela.Text = "Quantidade de parcelas:";
            // 
            // labelTaxaJuros
            // 
            this.labelTaxaJuros.AutoSize = true;
            this.labelTaxaJuros.Location = new System.Drawing.Point(12, 139);
            this.labelTaxaJuros.Name = "labelTaxaJuros";
            this.labelTaxaJuros.Size = new System.Drawing.Size(91, 13);
            this.labelTaxaJuros.TabIndex = 7;
            this.labelTaxaJuros.Text = "Taxa de juros (%):";
            // 
            // btnSimular
            // 
            this.btnSimular.Location = new System.Drawing.Point(15, 211);
            this.btnSimular.Name = "btnSimular";
            this.btnSimular.Size = new System.Drawing.Size(100, 33);
            this.btnSimular.TabIndex = 9;
            this.btnSimular.Text = "Simular";
            this.btnSimular.UseVisualStyleBackColor = true;
            this.btnSimular.Click += new System.EventHandler(this.btnSimular_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numParcela,
            this.vlrParcela,
            this.vlrJurosLin,
            this.vlrparcelaLin,
            this.vlrJurosExp,
            this.vlrParcelaExp});
            this.dataGridView1.DataSource = this.creditoDTOBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(141, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(647, 426);
            this.dataGridView1.TabIndex = 10;
            // 
            // creditoDTOBindingSource
            // 
            this.creditoDTOBindingSource.DataSource = typeof(Credito.DTO.CreditoDTO);
            // 
            // numParcela
            // 
            this.numParcela.DataPropertyName = "numParcela";
            this.numParcela.HeaderText = "Parcela";
            this.numParcela.Name = "numParcela";
            // 
            // vlrParcela
            // 
            this.vlrParcela.DataPropertyName = "vlrParcela";
            this.vlrParcela.HeaderText = "Principal Parcela";
            this.vlrParcela.Name = "vlrParcela";
            // 
            // vlrJurosLin
            // 
            this.vlrJurosLin.DataPropertyName = "vlrJurosLin";
            this.vlrJurosLin.HeaderText = "Juros Linear";
            this.vlrJurosLin.Name = "vlrJurosLin";
            // 
            // vlrparcelaLin
            // 
            this.vlrparcelaLin.DataPropertyName = "vlrParcelaLin";
            this.vlrparcelaLin.HeaderText = "Total Parcela Linear";
            this.vlrparcelaLin.Name = "vlrparcelaLin";
            // 
            // vlrJurosExp
            // 
            this.vlrJurosExp.DataPropertyName = "vlrJurosExp";
            this.vlrJurosExp.HeaderText = "Juros Exponencial";
            this.vlrJurosExp.Name = "vlrJurosExp";
            // 
            // vlrParcelaExp
            // 
            this.vlrParcelaExp.DataPropertyName = "vlrParcelaExp";
            this.vlrParcelaExp.HeaderText = "Total Parcela Exponencial";
            this.vlrParcelaExp.Name = "vlrParcelaExp";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSimular);
            this.Controls.Add(this.labelTaxaJuros);
            this.Controls.Add(this.labelQtdeDeParcela);
            this.Controls.Add(this.labelValorDoEmprestimo);
            this.Controls.Add(this.textBoxTaxaDeJuros);
            this.Controls.Add(this.textBoxQtdeDeParcelas);
            this.Controls.Add(this.textBoxValorDoEmprestimo);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.creditoDTOBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBoxValorDoEmprestimo;
        private System.Windows.Forms.TextBox textBoxQtdeDeParcelas;
        private System.Windows.Forms.TextBox textBoxTaxaDeJuros;
        private System.Windows.Forms.Label labelValorDoEmprestimo;
        private System.Windows.Forms.Label labelQtdeDeParcela;
        private System.Windows.Forms.Label labelTaxaJuros;
        private System.Windows.Forms.Button btnSimular;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource creditoDTOBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn numParcela;
        private System.Windows.Forms.DataGridViewTextBoxColumn vlrParcela;
        private System.Windows.Forms.DataGridViewTextBoxColumn vlrJurosLin;
        private System.Windows.Forms.DataGridViewTextBoxColumn vlrparcelaLin;
        private System.Windows.Forms.DataGridViewTextBoxColumn vlrJurosExp;
        private System.Windows.Forms.DataGridViewTextBoxColumn vlrParcelaExp;
    }
}

